"""
Using rdkit and scikit-learn to build a random forest based
on molecular fingerprints to predict inhibition of molecules

Not optimizes for predictive accurracy but just to test the SAIL
encryption framework
"""

import sys
from rdkit import Chem
from rdkit.Chem import AllChem
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix

import time

#hard-coding the data file
data_file = '../data/clean_data.txt'

#parse the file
inhib = []
SMILES = []

with open(data_file) as fh:
    data = fh.readlines()
    for elem in data:
        li = elem.rstrip().split('\t')
        inhib.append(float(li[0]))
        SMILES.append(li[-1])

#check that all the SMILES can be parsed by rdkit
#convert to hashes right away
valid_inhib = []
valid_hashes = []
counter = 0
t0 = time.time()
for smile in SMILES:
    m = Chem.MolFromSmiles(smile)
    if m is not None:
        fp = AllChem.GetMorganFingerprintAsBitVect(m,2,nBits=1024)
        fp = list(fp)
        #convert the floats into 0-1 for a classification problem
        #of inhibition or no inhibition
        if inhib[counter] < 0:
            valid_inhib.append(1)
        else:
            valid_inhib.append(0)
        valid_hashes.append(fp)
    counter += 1
t1 = time.time()
print('Generating fingerprints took {} sec(s)'.format(t1 - t0))
#convert to numpy arrays
X = np.array(valid_hashes)
y = np.array(valid_inhib)
print(np.sum(y)/y.shape[0])
#split to test and training
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
                random_state=42)

#build the classification model
t0 = time.time()
clf = RandomForestClassifier(n_estimators=100, max_depth=2,
                random_state=0)
clf.fit(X_train, y_train)

#predict on the test set
pred = clf.predict(X_test)
t1 = time.time()
print('Training and predicting took {} sec(s)'.format(t1 - t0))
print(pred)
#confusion matrix
conf = confusion_matrix(pred, y_test)
print(conf)
#np.save('result.npy', pred)
oracle = np.load('result.npy')
for i in range(pred.shape[0]):
    assert pred[i] == oracle[i]
