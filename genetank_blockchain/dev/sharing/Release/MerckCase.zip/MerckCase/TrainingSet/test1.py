import csv
from sklearn.tree import DecisionTreeRegressor
import numpy as np
import re

def getData(name):
    arr=[]
    with open(name,'r') as f:
      i=0
      while(True):
	      line =f.readline()
	      if not line:
	        print i
	        print len(line)
	        break
	      line = re.split(',|\n', line)
	      arr.append(line)
	      i+=1
    i=0
    while i<2377:
      if(arr[i][0]=='ACT1_M_134807'):
        print len(arr[i])
        print arr[i]
      i+=1
    data = np.array(arr)
    print data.shape
    header = data[1,-1]
    data = data[1:,1:-1]
    data=data.astype(np.float)
    x=data[:,1:]
    y=data[:,0]
    return [x,y]

def train(x,y):
	model = DecisionTreeRegressor(max_depth=4)
	model.fit(x,y)
	return model

if __name__ == '__main__':
  ans=getData('./3.csv')
  model = train(ans[0],ans[1])
  print model

