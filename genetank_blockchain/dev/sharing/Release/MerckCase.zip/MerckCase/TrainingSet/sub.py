import numpy as np
import csv

def getData(name):
	arr=None
	i=0
	with open(name, 'r') as csvfile:
		reader = csv.reader(csvfile, delimiter=',')
		for row in reader:
		    tmparr=np.asarray(row);
		    print i
		    i+=1
		    if arr is None:
		    	arr=tmparr
		    else:
		    	arr=np.vstack((arr, tmparr))
		    if i==1000:
		    	break;

	arr = arr[1:, 1:]
	arr = arr.astype(np.float)
	y=arr[:,1]
	x=arr[:,1:]
	esp = np.ones((x.shape[0],1))
	np.append(x,esp,axis=1)
	return x,y


def mse(w, x, y): 
    return np.mean((np.dot(x, w) - y)**2)/2
  
def gradients(w, x, y): 
    return 2*(np.dot(x.transpose(), (np.dot(x, w) - y)))

def local_LR(w, x, y, yeta, threshold=0.05): 
    prev_error = 0
  
    i=0
    delta=0
    while True: 
        error = mse(w, x, y)
        print error
        if error<=threshold:
        	break;
        prev_error = error 
        grad = gradients(w, x, y) 
        w=np.subtract(w,yeta*grad)
        i+=1
  
    return w

x,y=getData('ACT2_competition_training.csv')
w=np.transpose(np.random.normal(0,0.1,x.shape[1]))
w=local_LR(w,x,y,1e-7)
print w
print np.nonzero(w)