import numpy as np
import csv
import math

def getData(name):
    arr=[]
    with open(name,'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	for row in reader:
	    arr.append(row)
    data = np.array(arr)
    headerR = data[1,:]
    data = data[1:,1:]
    data=data.astype(np.float)
    return headerR,data

def getFeat(col):
    feats = [] 
    for i in col:
	if i not in feats:
            feats.append(i)
    return feats

def getBins(col, numBin):
    bmin=math.floor(min(col));
    bmax=math.ceil(max(col));
    print bmin
    print bmax
    binc=(bmax-bmin)/numBin;
    bbin=[0]*numBin
    for i in range(len(col)):
        col[i] = int(math.floor((col[i]-bmin)/binc))
    return col

def getEntropy(clabel, col, val, size):
    label = set(clabel)
    dic=[{},{}]
    for i in range(size):
	if col[i] <= val:
            if clabel[i] not in dic[0]:
                dic[0][clabel[i]]=0
            else:
                dic[0][clabel[i]]+=1
	else:
            if clabel[i] not in dic[1]:
                dic[1][clabel[i]]=0
            else:
                dic[1][clabel[i]]+=1
    csum=0
    tmp1=0
    tmp2=0
    for l in label:
        if l in dic[0]:
            tmp1+=dic[0][l]
        if l in dic[1]:
            tmp2+=dic[1][l]

    csum+=tmp1+tmp2
    print dic
    
    h=0
    for l in label:
        p1=0
        p2=0
        if (l in dic[0]) and tmp1!=0:
    	    p1=float(dic[0][l])/tmp1
        if (l in dic[1]) and tmp2!=0:
    	    p2=float(dic[1][l])/tmp2
        if p1!=0 and tmp1!=0:
    	    h+=-tmp1*p1*math.log(p1,2)/csum
        if p2!=0 and tmp2!=0:
            h+=-tmp2*p2*math.log(p2,2)/csum
    return h

def getTree(data, numBranch):
    label = data[:,0].transpose().tolist()
    lcol = getBins(label,8)
    data[:,0]=lcol
    tree=[]
    for i in range(1,(data.shape)[1]):
    	col = data[:,i].transpose().tolist()
    	feats=getFeat(col)
    	hmin = float('inf')
        fmin = float('inf')
    	for feat in feats:
    	    h=getEntropy(data[:,0].transpose().tolist(), data[:,i].transpose().tolist(), feat, (data.shape)[0])
    	    if h<hmin:
                hmin = h
    		fmin = feat
        tree.append([i, fmin, hmin])
    tree.sort(key = lambda x:x[2] )
    tree = tree[0:100]    
    return tree

if __name__ == '__main__':
    header, data = getData('./ACT2_competition_training.csv')
    tree = getTree(data, 20)
    print tree
