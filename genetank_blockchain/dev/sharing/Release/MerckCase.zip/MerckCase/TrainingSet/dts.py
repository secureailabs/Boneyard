import numpy as np
from sklearn.tree import DecisionTreeRegressor
import csv

def getData(name):
    arr=[]
    with open(name,'r') as csvfile:
	    reader = csv.reader(csvfile, delimiter=',')
	    for row in reader:
	        arr.append(row)
    data = np.array(arr)
    print data.shape
    print data
    header = data[1,:]
    data = data[1:,1:]
    data=data.astype(np.float)
    x=data[:,1:]
    y=data[:,0]
    return header,x,y

def getTData(name):
    arr=[]
    with open(name,'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	for row in reader:
	    arr.append(row)
    data = np.array(arr)
    header = data[1,:]
    data = data[1:,1:]
    data=data.astype(np.float)
    return header,data

def splitcsv(size,name):
    i = 0
    j = 0
    with open(name, 'r') as csvf:
        header = ''
        flag = True
        sname = str(j)+'.csv'
        f = open(sname, 'w')
        while(True):
            if i==0:
                header = csvf.readline()
            else:
                line = csvf.readline()
                if not line:
                    break
                if flag:
                    f.write(header)
                    flag = False
                f.write(line)
            if f.tell() > size:
                j+=1
                f.close()
                sname=str(j)+'.csv'
                f=open(sname, 'w')
                flag = True
            i+=1
        f.close()

def train(x,y):
	model = DecisionTreeRegressor(max_depth=4)
	model.fit(x,y)
	return model

if __name__ == '__main__':
  header,x,y=getData('./3.csv')
  model = train(x,y)
  print model

