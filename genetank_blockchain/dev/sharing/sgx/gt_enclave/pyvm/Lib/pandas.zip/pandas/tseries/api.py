"""
Timeseries API
"""

# flake8: noqa

from pandas.tseries.dfrequencies import infer_freq
import pandas.tseries.doffsets as offsets
